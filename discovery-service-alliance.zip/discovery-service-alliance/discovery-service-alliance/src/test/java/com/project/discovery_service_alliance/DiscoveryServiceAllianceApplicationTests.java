package com.project.discovery_service_alliance;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DiscoveryServiceAllianceApplicationTests {

	@Test
	void contextLoads() {
	}

}
